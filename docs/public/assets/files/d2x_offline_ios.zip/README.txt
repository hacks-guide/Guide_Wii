HOW TO RUN THIS SCRIPT

macOS: Right click the 'd2x_offline_ios.command' file and select "Open"

Linux: Open a terminal inside this folder and run "./d2x_offline_ios.command".
If you get a Permission Denied error (somehow), run "chmod +x d2x_offline_ios.command" first, then try the first command once more
